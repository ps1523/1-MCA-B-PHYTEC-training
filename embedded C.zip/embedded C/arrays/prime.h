int prime(void);
