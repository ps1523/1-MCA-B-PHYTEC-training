#include<stdio.h>
#include"oddeven.h"
int main()
{
	int n1,n2;
	printf("Enter the range :");
	scanf("%d%d",&n1,&n2);
	oddeven(n1,n2);
	return 0;
}
