#include<stdio.h>
int main()
{
	int marks[6],i;
	for(i=0;i<6;i++)
	{
		scanf("%d",&marks[i]);
	}
	for(i=0;i<6;i++)
	{
		printf("%d ",marks[i]);
	}
	return 0;
}
