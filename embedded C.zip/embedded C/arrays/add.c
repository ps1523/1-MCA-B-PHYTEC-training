#include"add.h"
void sum(void)
{
	int n1=10,n2=20;
	printf("%d",n1+n2);
}
