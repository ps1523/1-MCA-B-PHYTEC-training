#include<stdio.h>
int main()
{
	int data[10]={21,5,20,15,1,40,50,7,9,30};
	for(int i=0;i<10;i++)
		printf("%d ",data[i]);
	return 0;
}
