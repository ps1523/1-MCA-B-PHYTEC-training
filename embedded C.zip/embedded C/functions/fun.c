#include<stdio.h>
/*void sum(void)
{
	int n1=20,n2=30,result;
	result=n1+n2;
	printf("%d",result);
}*/
void sum(void);
int main()
{
	sum();
	return 0;
}
void sum(void)
{
        int n1=20,n2=30,result;
        result=n1+n2;
        printf("%d",result);
}
