int arm(int n);
