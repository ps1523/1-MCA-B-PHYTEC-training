void arithmetic(int x,int y);
