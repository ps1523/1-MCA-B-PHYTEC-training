#include<stdio.h>
#include"great.h"
int main()
{
	int n1,n2,res;
	res=great(n1,n2);
	printf("%d is Greatest",res);
	return 0;
}
