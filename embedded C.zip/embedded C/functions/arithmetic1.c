#include<stdio.h>
void arithmetic(int x,int y)
{
	printf("Add = %d",x+y);
	printf("\nSubtract = %d",x-y);
	printf("\nMultiplication = %d",x*y);
	printf("\nDivision = %d",x/y);
	printf("\nModulus = %d\n",x%y);

}
