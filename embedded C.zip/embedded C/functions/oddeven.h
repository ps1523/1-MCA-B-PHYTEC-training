void oddeven(int a,int b);
