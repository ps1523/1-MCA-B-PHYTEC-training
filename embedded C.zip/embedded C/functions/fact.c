#include"fact.h"
int main()
{
	fact();
	return 0;
}
