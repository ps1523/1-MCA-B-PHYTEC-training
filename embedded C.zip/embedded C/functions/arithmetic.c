#include<stdio.h>
#include "arithmetic.h"
int main()
{
	int a,b;
	printf("Enter a and b :");
	scanf("%d\n%d",&a,&b);
	arithmetic(a,b);
	return 0;
}
