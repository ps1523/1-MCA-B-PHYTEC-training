#include"add.h"
int main()
{
	sum();
	return 0;
}
