void fibonacci(int n,int a,int b);
