void fact(void);
