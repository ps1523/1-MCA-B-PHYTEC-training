void prime(void);
