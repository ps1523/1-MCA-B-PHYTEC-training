int great(int a,int b);
