#include"prime2.h"
int main()
{
	prime();
	return 0;
}
