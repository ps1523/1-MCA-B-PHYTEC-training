#include <stdio.h>

int main() {
    int x = 8;

    if (x > 5) {
        if (x < 10) {
            printf("x is between 5 and 10\n");
        }
    }

    return 0;
}

