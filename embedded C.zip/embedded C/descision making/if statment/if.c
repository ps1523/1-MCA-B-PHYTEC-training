#include <stdio.h>

int main() {
    int x = 10;

    if (x > 5) {
        printf("x is greater than 5\n");
    }

    return 0;
}
