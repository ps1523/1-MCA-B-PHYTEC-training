#include <stdio.h>

int main() {
    int a, b;

    printf("Enter two integers separated by a space: ");
    scanf("%d %d", &a, &b);

    printf("You entered: %d and %d\n", a, b);
    return 0;
}

