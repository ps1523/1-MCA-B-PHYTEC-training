#include <stdio.h>

int main() {
    int x = 4;

    if (x > 5) {
        printf("x is greater than 5\n");
    } else {
        printf("x is less than or equal to 5\n");
    }

    return 0;
}

