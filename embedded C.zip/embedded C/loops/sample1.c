#include<stdio.h>

int main()
{
	int n=10,i=0;
	while(i<=n)
	{
		printf("%d\n",i);
		i++;
	}
	return 0;
}

