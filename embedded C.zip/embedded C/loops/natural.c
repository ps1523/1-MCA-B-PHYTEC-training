#include<stdio.h>
int main()
{
	int i=0;
	while(i<=19)
	{
		i++;
		printf("%d\n",i);
	}
	return 0;
}
	
