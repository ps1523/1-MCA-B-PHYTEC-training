#include<stdio.h>
void print(void);
int main()
{
	print();
	return 0;
}
void print(void)
{
	printf("Hello I MCA B Section");
}
